export default function comments(defStore=[],action){

    switch(action.type){
        case 'ADD_COMMENT':
        console.log('Within Comments Reducer !');
        console.log(action);   
        // change the store Here !             
        return defStore;
        default:
        return defStore;
    }
}