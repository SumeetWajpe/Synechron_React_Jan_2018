export default function posts(defStore=[],action){
    
    switch(action.type){
        case 'INCREMENT_LIKES':
       
        // change the store Here !   
        
        let postIndex = action.index;
        
        return [

...defStore.slice(0,postIndex),
{...defStore[postIndex],likes:defStore[postIndex].likes + 1},
...defStore.slice(postIndex + 1)
        ];        
       
        default:
        return defStore;
    }
   
   

}