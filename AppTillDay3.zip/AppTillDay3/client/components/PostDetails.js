import React from 'react';

export default class PostDetails extends React.Component{
    render(){
       
        return <div className="postStyle">
            <h2> {this.props.post.caption} </h2>
<img src={this.props.post.display_src} height="100px" width="100px" />

            </div>
    }
}