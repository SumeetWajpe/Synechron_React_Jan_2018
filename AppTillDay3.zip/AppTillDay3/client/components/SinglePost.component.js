import React from 'react';

export default class SinglePost extends React.Component{
    render(){
        console.log(this.props.myposts);

        return <div>
            <h2> SinglePost Component </h2>
            </div>
    }
}