export function Increment(index){
        return {
            type:'INCREMENT_LIKES',
            index
        }
}

export function Decrement(){
    return {
        type:'DECREMENT_LIKES'
    }
}

export function AddComment(){
    return {
        type:'ADD_COMMENT'
    }
}

