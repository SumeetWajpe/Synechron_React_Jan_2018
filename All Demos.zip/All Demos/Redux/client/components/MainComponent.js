import React from 'react';

export default class Main extends React.Component{
    
    
    componentDidMount(){
        this.props.fetchPostsData();
    }
    render(){

            return <div>
            <h1> {this.props.myposts.length} </h1>
          
            {React.cloneElement(this.props.children,this.props)}
            </div>
    }
}