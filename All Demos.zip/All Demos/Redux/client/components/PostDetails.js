import React from 'react';
import {Link} from 'react-router';
 export default class PostDetails extends React.Component{
    render(){
       
        return <div className="postStyle">
            <h2> {this.props.post.caption} </h2>

            <Link to={`/singlePost/${this.props.post.code}`}>
<img src={this.props.post.display_src} height="100px" width="100px" />

</Link>
<br/>
<button type="button" onClick={this.props.Increment.bind(this,this.props.index)} className="btn btn-primary" >
{this.props.post.likes} &nbsp; <span className="glyphicon glyphicon-thumbs-up"></span>
</button>
            </div>
    }
}