import React from 'react';
import PostDetails from './PostDetails';

export default class AllPosts extends React.Component{
    render(){
        
        var postsToBeCreated = this.props.myposts.map((p,index)=>{
                return <PostDetails key={index} index={index} post={p} {...this.props} />
        });
        return <div>
            <h2> All Posts </h2>
            {postsToBeCreated}
            </div>
    }
}