import React from 'react';
import PostDetails   from './PostDetails';

export default class SinglePost extends React.Component{
    render(){
        

        // code Id

        var code = this.props.params.codeId;
         var index = this.props.myposts.findIndex((p,i)=> p.code == code);

       var currPost =this.props.myposts.find((p,i)=>{
                if(p.code == code){
                    return true;
                }
        });
        var postComments = this.props.mycomments[code]  || [];

        console.log(postComments);

        return <div>
            <PostDetails post={currPost} index={index} {...this.props} />
            </div>
    }
}