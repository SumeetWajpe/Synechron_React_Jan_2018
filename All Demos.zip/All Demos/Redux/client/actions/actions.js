import axios from 'axios';

export function Increment(index){
        return {
            type:'INCREMENT_LIKES',
            index
        }
}

export function Decrement(){
    return {
        type:'DECREMENT_LIKES'
    }
}

export function AddComment(){
    return {
        type:'ADD_COMMENT'
    }
}

export function fetchPostsData(){
    console.log('Within FetchPostsData !');

    // ajax request 

  var aPromise =   axios.get('http://localhost:7770/api/posts')

    return (dispatch)=>{

        aPromise.then((response) =>{
                    dispatch({type:'FETCH_POSTS',response})                    
        })

    }

}

