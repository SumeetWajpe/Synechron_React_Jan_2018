// Code Here

import React from 'react';
import ReactDOM from 'react-dom';
import BasicComponent from './basic.component';

import {CourseComponent} from './course.component'

import {ListOfCourses}
 from './listofcourses.component'
// 

import {CustomButtonComponent} from './custombutton.component'

import {ButtonListComponent} from './buttonlist.component'
import {LifeCycleComponent} from './lifecycle.component'
import {PostsComponent} from './posts.component'
// ReactDOM.render(<CustomButtonComponent initialCount={10} />,document.getElementById('content'));


ReactDOM.render(<ListOfCourses />,document.getElementById('content'));