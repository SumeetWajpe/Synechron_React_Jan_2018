

import React from 'react';

export default class BasicComponent extends React.Component{
    render(){                
            return (<div> <h1> H1 Component using JSX (ES6) & Webpack !</h1>
            <p> A Para !</p> 
            </div>)

    }
}

export var x = 100;
export var y = 100;
export var z = 100;
export var Square = (x) => x * x;
