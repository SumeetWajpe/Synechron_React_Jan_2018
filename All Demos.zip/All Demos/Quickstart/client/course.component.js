import React from 'react';
import PropTypes from 'prop-types';

export class CourseComponent extends React.Component{
    render(){
        return <div>
             <h1> {this.props.index} . {this.props.coursedetails.name} </h1>
             <b> Price : </b> {this.props.coursedetails.price} <br/>
             </div>
    }
}

CourseComponent.propTypes = {
    index : PropTypes.number
}

CourseComponent.defaultProps = {
    index:0,
    coursedetails : {
        name:'Unknown',
        price:0
    }
}