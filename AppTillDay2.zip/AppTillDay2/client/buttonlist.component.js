import React from 'react';
import ReactDOM from 'react-dom';

import {CustomButtonComponent} from './custombutton.component'
export class ButtonListComponent extends React.Component{  
   
    constructor(props){
        super(props);
        this.state ={buttonCounts: [10,20,30,50]};
    }
    addItemHandler(){
        // access the textbox !
            let theInput = ReactDOM.findDOMNode(this.refs.txtValueToBeAdded);

            // add the value to the collection

            this.setState({buttonCounts: [...this.state.buttonCounts, +(theInput.value)]})
    }
    render(){

        var buttonsToBeCreated = this.state.buttonCounts.map(function(c,ind){
            return <CustomButtonComponent initialCount={c} key={ind} />
        })

        return <div>


                Value : <input type="text" ref="txtValueToBeAdded" /> <input type="button"  value= "Add" className="btn btn-success"  onClick={this.addItemHandler.bind(this)} />

            {buttonsToBeCreated}
                   </div>
    }
}