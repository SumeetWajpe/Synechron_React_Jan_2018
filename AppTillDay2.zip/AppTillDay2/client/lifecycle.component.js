import React from 'react';
import ReactDOM from 'react-dom';

export class LifeCycleComponent extends React.Component{
    

    constructor(props){
        super(props);
        console.log('Within constructor');        
    
    }

    componentWillMount(){
        this.state = {coursename:'React'};
        console.log('Within componentWillMount')
    }

    componentDidMount(){
        console.log('Within componentDidMount');        
    }

    shouldComponentUpdate(){
        console.log(arguments);
        if(arguments[1].coursename.length > 10){
            return false
        }
        console.log('Within shouldComponentUpdate');        
        return true;
    }

    componentWillUpdate(){
        console.log('Within componentWillUpdate'); 
    }

    componentDidUpdate(){
        console.log('Within componentDidUpdate'); 
    }

    ChangeHandler(){
        let theInputValue = ReactDOM.findDOMNode(this.refs.theInput).value;
        console.log(theInputValue);
        this.setState({coursename:theInputValue})
    }
    
    
    render(){
        console.log('Within render');
        
        return <div>
        Course :    <input type="text" value={this.state.coursename} ref="theInput" onChange={this.ChangeHandler.bind(this)} />

            <label>{this.state.coursename}</label>
                       </div>
    }
}