// Code Here

import React from 'react';
import ReactDOM from 'react-dom';
import BasicComponent from './basic.component';

import {CourseComponent} from './course.component'

import {ListOfCourses}
 from './listofcourses.component'
ReactDOM.render(<ListOfCourses />,document.getElementById('content'));
